package edu.tum.ase.darkmode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DarkmodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
