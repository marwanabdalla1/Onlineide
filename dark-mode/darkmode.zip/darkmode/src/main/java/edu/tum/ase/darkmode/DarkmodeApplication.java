package edu.tum.ase.darkmode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DarkmodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DarkmodeApplication.class, args);
	}

}
